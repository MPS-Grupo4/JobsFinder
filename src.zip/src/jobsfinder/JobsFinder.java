package jobsfinder;


public class JobsFinder {
	
	public static void main (String[] args) {
            
	}
	
}